import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>
        This was amazing bootcamp by Shaurya sinha sir . we covered everything
        from basic scratch including Javascript, React.js, HTML. Thank you so
        much Shaurya sinha sir and ShapeAI we learned a lot by the bookcamp and
        it is very helpful for the future as well.
      </p>
    </div>
  );
}

export default Note;
